#!/bin/bash

HOST='185.62.188.4'
USER='ffastvpn_rey'
PASS='ffastvpn'
DB='ffastvpn_db'
