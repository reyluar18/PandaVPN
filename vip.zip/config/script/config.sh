#!/bin/bash

HOST='212.237.53.120'
USER='super'
PASS='Qwerty1234'
DB='super_db'
