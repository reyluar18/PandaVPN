
[
  {
	  "Name":"SUN-TU-PROMO",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FDEF99FA00FAA0FD6F87FA0DF97FAA6FAAEF6EFAABFAABFD6FAA0FA0AFAA6F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  }
]