
[
  {
	  "Name":"SUN - TU #1",
	  "Info":"TU Promo #1",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"A09F97FA0EFA08FD6FA0CF97FA09FA0AFD6FA08FA0EFAA0FA0AFD6FA09FA0AF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - TU #2",
	  "Info":"TU Promo #2",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - TU #3",
	  "Info":"TU Promo #3",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FAA9FA0AF99FA0DF97FAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - TU #4",
	  "Info":"TU Promo #4",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"AA9FAB0FD6FAACFA08FAAAFA0CFAAAFD6F99FAA0F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - TU #5",
	  "Info":"TU Promo #5",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FAA9FA0AF99FA0DF97FAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TM - A20",
	  "Info":"A20 TO 8080 RANDOM CAPP",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"A0AFAA0F99FAADFABAFAABFAA6FA0AFA00FDEFAA6F98FAA0FEAFD6FA0CFAAEFAA6F97FAA6FA0EF99FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TM - ASTIGFB10/15",
	  "Info":"ASTIGFB10/15 TO 8080",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"97FAABFAABFAAEFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09FD6FAABFA0EF99F97FAAEF97FD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM GSWITCH",
	  "Info":"Accet Offer",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"99FA08FA0EFA0AFAA0FAA6FAAEFEAFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM FB Promo #2",
	  "Info":"Any Fb Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"99FA08FA0EFA0AFAA0FAA6FAAEFEAFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM GoWatch #1",
	  "Info":"GOSURF50/EZ50 TO 8080",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"A0BFAADFA0AFA0AFABAFAAAFAA7FAA6FAA7F98FA0AFD6FAAEFAA7FAA0F98FAADFAAAF97FA00F98F97FAA0FA00FD6F99FAAAFA09FD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM GoWatch #2",
	  "Info":"GOSURF50/EZ50 TO 8080",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FA0CFAAAFAAAFA0CFA08FA0AFAA8FA0EFA00FA0AFAAAFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"ALL NETWORK",
	  "Info":"Youtube Promo #1",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"ALLNETWORK",
	  "Info":"Youtube Promo #2",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"ABAFAA6FEAFD6FA0CFA0CFAABFA0DFAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT - IG10",
	  "Info":"IG Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FA0EFAA0FAAEFAA6F97FA0CFAADF97FA09FD6F99FAAAFA09FD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT - ML10",
	  "Info":"Promo #1",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"AA9FA0AF98FD6FA09FAAAF98FA0EFA08FA0AFA08FA0AFA0CFA0AFAA0FA00FAAEFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT",
	  "Info":"SC Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SMART ALLOUT #1",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SMART ALLOUT #2",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"D8FD6FA0BFAADFA0AFA0AF98F97FAAEFA0EF99FAAEFD6F99FAAAFA09FD6FAAAFAA0FA08FA0EFAA0FA0AFD6FAAEFA09F97FAADFAA6FAABF97FA00F97FA08F97FD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SMART MB Promo",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"D8FD6FA0BFAADFA0AFA0AF98F97FAAEFA0EF99FAAEFD6F99FAAAFA09FD6FAAAFAA0FA08FA0EFAA0FA0AFD6FAAEFA09F97FAADFAA6FAABF97FA00F97FA08F97FD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SMART No-Load [Beta]",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"128.199.69.85",
			  "Port":"8080"
		  },
		  "Url":"D8FD6FA0BFAADFA0AFA0AF98F97FAAEFA0EF99FAAEFD6F99FAAAFA09FD6FAAAFAA0FA08FA0EFAA0FA0AFD6FAAEFA09F97FAADFAA6FAABF97FA00F97FA08F97FD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
]