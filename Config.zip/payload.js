
[
  {
	  "Name":"SUN TU Promo #1",
	  "Info":"Register to TU50/60/150",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"A09F97FA0EFA08FD6FA0CF97FA09FA0AFD6FA08FA0EFAA0FA0AFD6FA09FA0AF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN TU Promo #2",
	  "Info":"Register to TU50/60/150",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"AA9FA0AFA0EFAB0FD6FAACFA08FAAAFA0CFAAAFD6F99FAA0F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN TU Promo #3",
	  "Info":"Register to TU50/60/150",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FAA9FA0AF99FA0DF97FAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM Promo #1",
	  "Info":"Register to Gosurf or Gowatch or Gotscombo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"99FA08FA0EFA0AFAA0FAA6FAAEFEAFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM Promo #2",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FA0CFAAAFAAAFA0CFA08FA0AFAA8FA0EFA00FA0AFAAAFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"ALL NETWORK #1",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"ALLNETWORK #2",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"ABAFAA6FEAFD6FA0CFA0CFAABFA0DFAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT IG Promo",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FA0EFAA0FAAEFAA6F97FA0CFAADF97FA09FD6F99FAAAFA09FD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT SC Promo",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SMART ALLOUT Promo",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
]