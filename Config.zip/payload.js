
[
 {
	  "Name":"SAKTO20",
	  "Info":"Avoid Torrent Site",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"www.viber.com.edgekey.net.pandafree.pandafreevpn.ml",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FAA8FA0EF98FA0AFAADFD6F99FAAAFA09FD6FA0AFA00FA0CFA0AFA07FA0AFABAFD6FAA0FA0AFAA6F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
 {
	  "Name":"SUN TU PROMO (NEW)",
	  "Info":"Avoid Torrent Site",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"m.wechat.com.proxy.pandafreevpn.ml",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FAA9FA0AF99FA0DF97FAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
 {
	  "Name":"GIGASTORIES",
	  "Info":"Avoid Torrent Site",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"api-30-0-0.twitter.com.proxy.pandafreevpn.ml",
			  "Port":"8080"
		  },
		  "Url":"97FAABFA0EFDEFEAFD8FDEFD8FDEFD8FD6FAA6FAA9FA0EFAA6FAA6FA0AFAADFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
 {
	  "Name":"GIGAVIDEO",
	  "Info":"Avoid Torrent Site",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"img.iwantv.com.proxy.pandafreevpn.ml",
			  "Port":"8080"
		  },
		  "Url":"A0EFA09FA0CFD6FA0EFAA9F97FAA0FAA6FAA8FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
 {
	  "Name":"ML",
	  "Info":"Avoid Torrent Site",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"jp.mobilelegends.com.pandafreevpn.ml",
			  "Port":"8080"
		  },
		  "Url":"A06FAABFD6FA09FAAAF98FA0EFA08FA0AFA08FA0AFA0CFA0AFAA0FA00FAAEFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  }


]
