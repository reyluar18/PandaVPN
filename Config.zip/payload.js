
[
  {
	  "Name":"SUN-TU-PROMO",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"178.128.218.191",
			  "Port":"8080"
		  },
		  "Url":"A09F97FA0EFA08FD6FA0CF97FA09FA0AFD6FA08FA0EFAA0FA0AFD6FA09FA0AF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  }
]
