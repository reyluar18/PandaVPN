
[
 {
	  "Name":"DEFAULT",
	  "Info":"Avoid Torrent Site",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"free.pandafreevpn.ml",
			  "Port":"8080"
		  },
		  "Url":"A08FA0EFAA0FA0AFD6FAA6FA0AFA08FA0AFA0CFAADF97FA09FD6FA09FA0AF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  }
]
