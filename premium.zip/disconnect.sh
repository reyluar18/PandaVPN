#!/bin/bash

DB='cablenet_rad-server'
DBADMIN='cablenet_radius'
DBPASSWD='cpsess2821051701'
DBHOST='185.61.137.173'

mysql -u$DBADMIN -p$DBPASSWD -h$DBHOST -e "UPDATE users SET bandwidth_premium=bandwidth_premium +'$bytes_received' WHERE user_name='$common_name'" $DB