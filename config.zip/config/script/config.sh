#!/bin/bash

HOST='ffastvpn.cf'
USER='ffastvpn_rey'
PASS='ffastvpn'
DB='ffastvpn_db'




